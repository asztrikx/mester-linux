#include <bits/stdc++.h>
#include "csavarok.h"

using namespace std;

int main(){
// deklaracio
    int n;
// megoldas
    n=kezdet();

    int elsoParViszonya=proba(1,1); // indexelés 1-tõl
    // ...
    int valamelyikParViszonya=proba(3,n-1); // 3. csavar és utolsó elõtti anya viszonya
    // ...
    int utolsoParViszonya=proba(n,n); // indexelés n-ig

    // be1.txt-ben lévő adatokra a válasz:
    int b[4]={3,4,2,1};
    // használhatnád az EgeszTomb nevű típust is, amit a csavarok is használ.
    eredmeny(b);

    return 0;
}

