#ifndef CSAVAROK_H
#define CSAVAROK_H

extern int kezdet();
extern int proba(int a, int b);
extern void eredmeny(int b[]);

#endif // CSAVAROK_H
