extern int induloszam();
extern int kerdes(int i, int j);
extern void megoldas(int m);
