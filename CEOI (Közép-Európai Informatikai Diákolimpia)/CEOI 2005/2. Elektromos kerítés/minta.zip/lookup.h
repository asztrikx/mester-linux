#ifdef __cplusplus
extern "C" {
#endif

extern int Drift (long x, long y, long z);
extern long GetN(void);
extern void Answer (long left, long right);

#ifdef __cplusplus
}
#endif
