#include "lookup.h"
#include <bits/stdc++.h>
#define MaxN 100000

using namespace std;

typedef struct PointType {
  long x, y;
} PointType;

int Init = true;
long N;
PointType P[MaxN + 3];
PointType A, B;

static void ReadIn(void){
  long x, y;
   cin>>A.x>>A.y>>B.x>>B.y;
   cin>>N;
  for (int i = 1; i <= N; i++) {
      cin>>x>>y;
    P[i].x = x;
    P[i].y = y;
  }
  P[N+1] = A;
  P[N+2] = B;
  Init = false;
}  /*Readin*/

int Drift(long x, long y, long z){
  /*Returns: +1 if x->y->z turns left,
             0 if x,y and z are collinear,
            -1 if x->y->z turns right*/
  long crosspr;
  if (Init)
    ReadIn();
  if (x < 1 || y < 1 || z < 1 || x > N + 2 || y > N + 2 || z > N + 2) {
    printf("Hiba, illeg�lis Drift argumentum\n");
    exit(1);
  }
  crosspr = (P[y].x - P[x].x) * (P[z].y - P[x].y) -
	    (P[z].x - P[x].x) * (P[y].y - P[x].y);
  if (crosspr < 0)
    return -1;
  else if (crosspr > 0)
    return 1;
  else
    return 0;
}  /*Drift*/

long GetN(void){
  if (Init) {
    ReadIn();
    Init = false;
  }
  return N;
}

void Answer(long left, long right){
  if (Init) {
    cout<<"HIBA, el�bb GetN-t kell h�vni";
    exit(1);
  }
  cout<<left<<" "<<right<<endl;
  exit(0);
}
