extern long GetN();
extern long isOnLine(long x, long y, long z);
extern void Answer(long a1, long b1, long a2, long b2);

