#include <stdlib.h>
#include <iostream>
#include <string>
#include "office.h"
#define MaxN	100001L
using namespace std;

bool Init = true;
long N, N1, Qnum, maxQ1, maxQ2, maxQ4;
bool Line1[MaxN];


void Fin(bool OK, string S){
int point;
   if (OK) {
      if (Qnum <= maxQ4) {
         point = 4;
         S=" <=N/2+2\n";
    } else if (Qnum <= maxQ2) {
         point = 2;
         S=" <=2N/3+3\n";
    } else {
         point = 1;
         S=" <=N-3\n";
    }
    cout<<point<<endl;
    cout<<"Helyes"<<endl;
    cout<<"#K�rd�sek= "<<Qnum<<S<<endl;
    exit(0);
  }
  cout<<"0"<<endl;
  cout<<S<<endl;
  cout<<"#K�rd�sek= "<<Qnum<<S<<endl;
  exit(0);
}

void doInit(){
  long i, x;
   cin>>N>>N1;
  for (x = 1; x <= N; x++)
    Line1[x] = false;
  for (i = 1; i <= N1; i++) {
      cin>>x;
    Line1[x] = true;
  }
  Qnum = 0;
  maxQ1 = N - 3;
  maxQ2 = N * 2 / 3 + 3;
  maxQ4 = N / 2+2;
}  /*doInit*/

long GetN(){
  if (Init) {
    doInit();
    Init = false;
  }
  return N;
}

long isOnLine(long x, long y, long z){
  if (Init)
    Fin(false, "Protokoll hiba\n");
  if (x < 1 || x > N || y < 1 || y > N || z < 1 || z > N)
    Fin(false, "Protokoll hiba\n");

  Qnum++;
  if (Qnum > maxQ1)
    Fin(false, "Protokoll hiba\n");
  if (Line1[x] && Line1[y] && Line1[z] || !Line1[x] && !Line1[y] && !Line1[z])
    return 1;
  else
    return 0;
}  /*isOnLine*/

void Answer(long a1, long b1, long a2, long b2){
  if (a1 < 1 || a1 > N || b1 < 1 || b1 > N || a2 < 1 || a2 > N || b2 < 1 ||
      b2 > N || a1==b1 || a2==b2)
    Fin(false, "Protokoll hiba\n");
  if (Line1[a1] && Line1[b1] && !Line1[a2] && !Line1[b2] ||
      !Line1[a1] && !Line1[b1] && Line1[a2] && Line1[b2])
    Fin(true, "Helyes\n");
  else
    Fin(false, "Hib�s v�lasz\n");
}  /*Answer*/
