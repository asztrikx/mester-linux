void init(int N, int D, int H[]) {
    // TODO
}

void curseChanges(int U, int A[], int B[]) {
    // TODO
}

int question(int X, int Y, int V) {
    return 1000000000;
}
