#include <cassert>
#include <iostream>

void init(int N, int D, int H[]);
void curseChanges(int U, int A[], int B[]);
int question(int X, int Y, int V);

int main() {
  /* ===== Start of input section =========================================== */
  /* Change this section to try other inputs */
  const int N  =  6,
            D  =  5,
            Q  =  4,
            U  =  11;

  int H[N] = { 2, 42, 1000, 54, 68, 234};

  // Changes
  //          1. 2. 3. 4. 5. 6. 7. 8. 9.10.11.
  int A[U] = {0, 2, 3, 3, 3, 1, 5, 0, 3, 1, 3},
      B[U] = {1, 0, 4, 5, 5, 3, 3, 5, 0, 3, 5};

  // Queries
  int X[Q]   = {  0, 3,          0,  3},
      Y[Q]   = {  3, 0,          5,  0},
      V[Q]   = {  4, 8,          5, 11},
      Ans[Q] = { 26, 0, 1000000000, 14};
  /* ===== End of input section ============================================= */

  // Limits for sanity checking of input
  const static int MAX_N = 100000,
                   MAX_D = 500,
                   MAX_U = 200000,
                   MAX_Q = 500000,
                   MAX_F = 1000000000;

  assert((N >= 0) && (N <= MAX_N)); assert((D >= 0) && (D <= MAX_D));
  for (int i=0; i<N; i++) assert(H[i] <= MAX_F);
  init(N, D, H);

  assert((U >= 0) && (U <= MAX_U));
  for (int i=0; i<U; i++) assert((A[i] >= 0) && (A[i] < N)), assert((B[i] >= 0) && (B[i] < N)), assert(A[i] != B[i]);
  curseChanges(U, A, B);

  bool correct = true;
  for (int i=0; i<Q; i++) {
    assert((X[i] >= 0) && (X[i] < N)); assert((Y[i] >= 0) && (Y[i] < N)); assert(X[i] != Y[i]); assert((V[i] >= 0) && (V[i] <= U));
    int ContestantAnswer = question(X[i],Y[i],V[i]);

    if (ContestantAnswer != Ans[i]) {
      std::cout << "Wrong Answer: X=" << X[i] << " Y=" << Y[i] << " V=" << V[i]
                << " Expected: " << Ans[i] << " Got: " << ContestantAnswer << std::endl;
      correct = false;
    } else {
        std::cout << "Correct Answer: X=" << X[i] << " Y=" << Y[i] << " V=" << V[i]
                << " Expected: " << Ans[i] << " Got: " << ContestantAnswer << std::endl;
    }
  }

  if (correct)
    std::cout << "All Correct!" << std::endl;
  return 0;
}

