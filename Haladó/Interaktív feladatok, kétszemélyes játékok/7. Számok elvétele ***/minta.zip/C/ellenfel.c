#include "ellenfel.h"
#include <stdio.h>
#include <stdlib.h>

#define MaxN            1000
#define true 1
#define false 0 

static int Init = false;
static long P1, P2;
static int N;
static int A[MaxN + 3];
static int ix;

static void vege(int pont, char* msg) {
	printf("%s\n", msg);
	exit(0);
}

int Meret()
{
	int i, FORLIM;

	scanf("%ld", &N);
	FORLIM = N;
	for (i = 0; i < FORLIM; i++) {
		scanf("%ld", &A[i]);
	}

	Szamit();

	P1 = 0;
	P2 = 0;
	ix = 1;

	Init = true;

	return N;
}


int Tabla(i)
int i;
{
	/*Tabla*/
	if (!Init) {
		vege(0, "hiba, el?sz�r Meret-et kell h�vni");
	}
	if (i < 1 || i > N) {
		vege(0, "hiba, �rv�nytelen param�ter Tabla-ban");
	}
	return (A[i - 1]);
}

void EnLep(L)
int L;
{
	long Pl;
	int i;

	/*EnLep*/
	if (!Init) {
		vege(0, "hiba, el?sz�r Meret-et kell h�vni");
	}
	if (L < 1 || L > 3 || ix + L - 1 > N) {
		vege(0, "hiba, �rv�nytelen param�ter EnLep-ben");
	}
	Pl = 0;
	for (i = -1; i <= L - 2; i++)
		Pl += A[ix + i];
	ix += L;
	P1 += Pl;
	if (ix == N + 1) {
		if (P1 <= P2) {
			vege(0, "hiba, vesztett�l");
		}
		vege(1, "helyes");
	}
}


int TeLep()
{
	long  Pl;
	int L, i;

	/*Telep*/
	if (ix <= N - 2) {
		L = 3;
	}
	else {
		L = N + 1 - ix;
	}
	Pl = 0;
	for (i = -1; i <= L - 2; i++)
		Pl += A[ix + i];
	ix += L;
	P2 += Pl;
	if (ix == N + 1) {
		if (P1 <= P2) {
			vege(0, "hiba, vesztett�l");
		}
		vege(1, "helyes");
	}
	return L;
}
