#ifdef __cplusplus
extern "C" {
#endif 

extern long GetN();
extern int GetH();
extern int Kerdes(long A, long B);
extern void Megoldas(long x);

#ifdef __cplusplus
}
#endif 
