#include <stdio.h>
#include <stdlib.h>
#include "eva.h"

#define MaxH            15
#define MaxM            4000001L
#define true 1
#define false 0

int Init = true;
long _N, _H, _M;
long _L[MaxH][MaxM];
long _bal, _jobb, _mH, _Kerd, _optM;

void Vege(ki, msg)
int ki;
char *msg;
{
	printf("%s\n", msg);
	exit(0);
}  /*Vege*/

void Elofel() {
	scanf("%ld%ld%*[^\n]", &_N, &_H);
	_bal = 1;
	_jobb = _N;
	_Kerd = 0;
	Init = false;
}  /*Elofel*/

long GetN() {
	if (Init) {
		Elofel();
		Init = false;
	}
	return _N;
}  /*GetN*/

int GetH() {
	if (Init) {
		Elofel();
		Init = false;
	}
	return _H;
}  /*GetH*/

int Kerdes(long A, long B) {
	long v;

	if (Init) {
		Vege(0, "hiba, el?sz�r GetN-t kell h�vni");
	}
	if (A < 1 || A > _N || B < 1 || B > _N || A > B) {
		Vege(0, "hiba, �rv�nytelen param�ter Kerdes-ben");
	}
	if (A < _bal)
		A = _bal;
	if (B > _jobb)
		B = _jobb;
	v = 0;
	_bal = A;
	_jobb = B;
	_Kerd++;
	return v;
}  /*Kerdes*/

void Megoldas(long x) {
	if (Init) {
		Vege(0, "hiba, el?sz�r GetN-t kell h�vni");
	}
	if (_bal != _jobb) {
		Vege(0, "hiba, bl�ff�lt�l");
	}
	if (x != _bal)
		Vege(0, "hiba, rossz v�lasz");
	Vege(1, "helyes");
}  /*Megoldas*/
