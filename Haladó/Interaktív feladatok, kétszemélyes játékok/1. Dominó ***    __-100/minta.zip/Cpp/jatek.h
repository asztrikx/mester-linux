#ifdef __cplusplus
extern "C" {
#endif

extern int Meret (void);
extern int D1 (int i);
extern int D2 (int i);
extern void EnLep (int L);
extern int TeLep (void);

#ifdef __cplusplus
}
#endif
