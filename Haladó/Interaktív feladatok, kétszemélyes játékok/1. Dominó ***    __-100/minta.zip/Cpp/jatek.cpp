#include "jatek.h"
#include <stdio.h>
#include <stdlib.h>

#define MaxN            100
#define true 1
#define false 0

typedef struct _REC_D {
	char x, y;
} _REC_D;

static int Init = false;
static int P1, P2, N;
static _REC_D D[MaxN + 1];
static int Bal, Jobb, x, y;

void message(int point, const char* msg) {
	printf("%s\n", msg);
	exit(0);
}

int Meret(void)
{
	int Result;
	int i, FORLIM;
	int TEMP, TEMP1;
	int SETIO;

	/*Meret*/
	SETIO = scanf("%ld", &N);
	if (SETIO == 0) {
		exit(0);
	}

	FORLIM = N;
	for (i = 0; i <= FORLIM; i++) {
		SETIO = scanf("%d%d", &TEMP, &TEMP1);
		if (SETIO == 0) {
			exit(0);
		}
		D[i].x = TEMP;
		D[i].y = TEMP1;
	}

	Bal = 1;
	Jobb = N;
	P1 = 0;
	P2 = 0;
	x = D[0].x;
	y = D[0].y;
	Init = true;

	Result = N;
	return Result;
}

int D1(int i)
{
	/*D1*/
	if (!Init) {
		message(0, "hiba: el?sz�r a Meret elj�r�st kell h�vni");
	}
	if (i < 0 || i > N) {
		message(0, "hiba, �rv�nytelen param�ter D1-ben");
	}
	return (D[i].x);
}

int D2(int i)
{
	/*D2*/
	if (!Init) {
		message(0, "hiba: el?sz�r a Meret elj�r�st kell h�vni");
	}
	if (i < 0 || i > N) {
		message(0, "hiba, �rv�nytelen param�ter D2-ben");
	}
	return (D[i].y);
}


void EnLep(int L)
{
	int x1, y1;

	/*EnLep*/
	if (!Init) {
		message(0, "hiba: el?sz�r a Meret elj�r�st kell h�vni");
	}
	if (L < 1 || L > 6) {
		message(0, "hiba, �rv�nytelen param�ter EnLep-ben");
	}
	switch (L) {   /*case*/

	case 1:
		x1 = D[Bal].x;
		y1 = D[Bal].y;
		Bal++;
		if (x == x1)
			x = y1;
		else if (x == y1)
			x = x1;
		else {
			message(0, "hiba, �rv�nytelen l�p�s, nem illeszkedik");
		}
		break;

	case 2:
		x1 = D[Bal].x;
		y1 = D[Bal].y;
		Bal++;
		if (y == x1)
			y = y1;
		else if (y == y1)
			y = x1;
		else {
			message(0, "hiba, �rv�nytelen l�p�s, nem illeszkedik");
		}
		break;

	case 3:
		x1 = D[Jobb].x;
		y1 = D[Jobb].y;
		Jobb--;
		if (x == x1)
			x = y1;
		else if (x == y1)
			x = x1;
		else {
			message(0, "hiba, �rv�nytelen l�p�s, nem illeszkedik");
		}
		break;

	case 4:
		x1 = D[Jobb].x;
		y1 = D[Jobb].y;
		Jobb--;
		if (y == x1)
			y = y1;
		else if (y == y1)
			y = x1;
		else {
			message(0, "hiba, �rv�nytelen l�p�s, nem illeszkedik");
		}
		break;

	case 5:
		if (x == D[Bal].x || x == D[Bal].y || y == D[Bal].x || y == D[Bal].y ||
			x == D[Jobb].x || x == D[Jobb].y || y == D[Jobb].x ||
			y == D[Jobb].y) {
			message(0, "hiba, �rv�nytelen l�p�s, lenne illeszked�s");
		}
		Bal++;
		P1++;
		break;

	case 6:
		if (x == D[Bal].x || x == D[Bal].y || y == D[Bal].x || y == D[Bal].y ||
			x == D[Jobb].x || x == D[Jobb].y || y == D[Jobb].x ||
			y == D[Jobb].y) {
			message(0, "hiba, �rv�nytelen l�p�s, lenne illeszked�s");
		}
		Jobb--;
		P1++;
		break;
	}
}


int TeLep(void)
{
	int Result;
	if (D[Bal].x == x || D[Bal].y == x) {
		Result = 1;
		x = D[Bal].x == x ? D[Bal].y : D[Bal].x;
		++Bal;
	}
	else if (D[Bal].x == y || D[Bal].y == y) {
		Result = 2;
		y = D[Bal].x == y ? D[Bal].y : D[Bal].x;
		++Bal;
	}
	else if (D[Jobb].x == x || D[Jobb].y == x) {
		Result = 3;
		x = D[Jobb].x == x ? D[Jobb].y : D[Jobb].x;
		--Jobb;
	}
	else if (D[Jobb].x == y || D[Jobb].y == y) {
		Result = 4;
		y = D[Jobb].x == y ? D[Jobb].y : D[Jobb].x;
		--Jobb;
	}
	else {
		Result = 5;
		++Bal;
		++P2;
	}

	if (Bal > Jobb) {
		if (P1 < P2) {
			message(1, "helyes");
		}
		else {
			message(0, "hiba, vesztett�l");
		}
	}
	return Result;
}
