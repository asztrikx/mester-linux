#ifdef __cplusplus
extern "C" {
#endif

extern void MyMove(int i);
extern int YourMove(void);
extern int Pit(int i);

#ifdef __cplusplus
}
#endif

