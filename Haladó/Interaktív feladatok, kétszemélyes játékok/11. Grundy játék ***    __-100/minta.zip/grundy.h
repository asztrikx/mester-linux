void Kezd(int n);
void EnLepesem(int &m, int &k);
void TeLepesed(int m, int k);
