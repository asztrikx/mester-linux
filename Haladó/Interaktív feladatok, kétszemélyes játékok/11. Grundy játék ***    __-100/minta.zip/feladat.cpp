#include <iostream>
#include "grundy.h"

using namespace std;

void Kezd(int n){

}
void EnLepesem(int &m, int &k){

}
void TeLepesed(int m, int k){

}

