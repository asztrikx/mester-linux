extern void KavicsokSzama(int &m, int &n);
extern void EnLepesem(int k1, int k2);
extern void TeLepesed(int &k1, int &k2);
