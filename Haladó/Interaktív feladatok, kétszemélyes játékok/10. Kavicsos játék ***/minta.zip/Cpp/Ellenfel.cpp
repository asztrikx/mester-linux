#include <iostream>
#include <stdlib.h>
#include <string>
#include "Ellenfel.h"
using namespace std;
int _A,_B;//_A kavicsok száma _A két kupacban

void KavicsokSzama(int &m, int &n){
   cin>>_A>>_B;
   m=_A;
   n=_B;
}

void EnLepesem(int k1, int k2){
   if(!(k1==0 && k2>0 && k2<=_B || k2==0 && k1>0 && k1<=_A || k1>0 && k1==k2 && k1<=_A && k2<=_B)){
      cout<<"Hibás lépés"<<endl;
      exit(0);
   }
   _A-=k1; _B-=k2;
   if(_A==0 && _B==0){
       cout<<"Nyertél!"<<endl;
       exit(0);
   }

   if(_A==0 || _B==0 || _A==_B){
      cout<<"Vesztettél!"<<endl;
      exit(0);
   }
   _A--; _B--; //az ellenfél lépése
}
void TeLepesed(int &k1, int &k2){
   k1=1; k2=1;
}

