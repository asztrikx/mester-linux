#ifndef INTERAKTIV_KAVICSHALOM_ELLENFEL
#define INTERAKTIV_KAVICSHALOM_ELLENFEL

long GetN();
long Elvesz(long x);

#endif