#ifndef INTERAKTIV_FIZETOS_EVA
#define INTERAKTIV_FIZETOS_EVA

int GetN();
int P(int x);
int Kerdes(int x);
void Megoldas(int x);

#endif 
