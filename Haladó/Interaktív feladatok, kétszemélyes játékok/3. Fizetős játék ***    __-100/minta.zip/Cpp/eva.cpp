#include "eva.h"
#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;

#define MaxN            1000
#define Inf             (MaxN * MaxN)
#define true 1
#define false 0

int _N;
int _Pt[MaxN + 1];
int _bal, _jobb;
long _kolt;
int _Init = true;

void Kiir(int, const string& msg)
{
	cout << msg << endl;
	exit(0);
}

void _BeolVas()
{
	int x, y;
	cin >> _N;

	for (x = 1; x <= _N; x++) {
		cin >> y;
		_Pt[x] = y;
	}
}  /*BeolVas*/

int GetN()
{
	if (!_Init) {
		Kiir(0, "hiba, GetN-t csak egyszer szabad h�vni");
	}
	_BeolVas();
	_bal = 1;
	_jobb = _N;
	_kolt = 0;
	_Init = false;
	return _N;
}  /*GetN*/

int P(int x)
{
	if (_Init) {
		Kiir(0, "hiba, el?sz�r GetN-t kell h�vni");
	}
	if (x < 1 || x > _N) {
		Kiir(0, "hiba, �rv�nytelen P argumentum");
	}
	return (_Pt[x]);
}  /*P*/

int Kerdes(int x)
{
	if (_Init) {
		Kiir(0, "hiba, el?sz�r GetN-t kell h�vni");
	}
	if (x < 1 || x > _N) {
		Kiir(0, "hiba, �rv�nytelen Kerdes argumentum");
	}
	_kolt += _Pt[x];
	if (x < _bal)
		return 0;
	if (x >= _jobb)
		return 1;
	/*_bal<=x<_jobb*/
	if (x < (_bal + _jobb) / 2) {
		_bal = x + 1;
		return 0;
	}
	else {
		_jobb = x;
		return 1;
	}
}  /*Kerdes*/

void Megoldas(int x)
{
	if (_Init) {
		Kiir(0, "hiba, el?sz�r GetN-t kell h�vni");
	}
	if (_bal < _jobb) {
		Kiir(0, "hiba, bl�ff�lt�l");
	}
	if (x != _bal) {
		Kiir(0, "hiba, rossz v�lasz");
	}
	Kiir(0, "helyes");
}  /*Megoldas*/
