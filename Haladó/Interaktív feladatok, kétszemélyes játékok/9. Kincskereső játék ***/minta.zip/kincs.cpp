//gyakorló modul, az értékelő nem így dolgozik
#include <iostream>
#include <stdlib.h>
#define maxN 10001
using namespace std;

int _F[maxN];
int _n;
int _Init=true;

void _Kezd(){
   cin>>_n;
   for(int i=2;i<=_n; i++){
      _F[i]=rand()%(i-1)+1;
   }
   _F[1]=0;
   _Init=false;
}
void Ki(string s){
  cout<<s<<endl;
  exit(0);
}
int Helyekszama(){
   if (_Init) {
      _Kezd();
   }
   return _n;
}
int Szomszed(int x){
   if(_Init){
      Ki("Protokoll hiba, elõbb hívd a Helyekszama mûveletet!");
   }
   if(x<1 || x>_n){
      Ki("Protokoll hiba, hibás sorszám!");
   }
  return _F[x];
}
int Ittvan(int x){
   if(_Init){
      Ki("Protokoll hiba, elõbb hívd a Helyekszama mûveletet!");
   }
   if(x<1 || x>_n){
      Ki("Protokoll hiba, hibás sorszám!");
   }
   return(_F[x]);
}
void Kincshely(int x){
   if(_Init){
      Ki("Protokoll hiba, elõbb hívd a Helyekszama mûveletet!");
   }
   if(x<1 || x>_n){
      Ki("Protokoll hiba, hibás sorszám!");
   }
   if(x!=1){
      Ki("Hiba, hibás válasz!");
   }
   Ki("HELYES");
}
