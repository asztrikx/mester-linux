#include <cstdio>
#include <cstdlib>
#include "eva.h"

#define MaxN            501
#define Infi            2000000000L

bool Init = true;
int _N, _K;
int _F[MaxN];
int _bal, _jobb;

void Vege(int ki, char *msg)
{
	printf("%s\n", msg);
	exit(0);
}  /*Vege*/

void Elofel() {
	int x, y, r;
	long Oxry;

	scanf("%d%d", &_N, &_K);
	for (x = 1; x <= _N; x++) {
		scanf("%d", &y);
		_F[x] = y;
	}
	_bal = 1;
	_jobb = _N;
	Init = false;
}  /*Elofel*/

int GetN() {
	if (Init) {
		Elofel();
		Init = false;
	}
	return _N;
}  /*GetN*/

int GetK() {
	if (Init) {
		Elofel();
		Init = false;
	}
	return _K;
}  /*GetK*/

int GetP(int x) {
	if (Init) {
		Elofel();
		Init = false;
	}
	if (x<1 || x>_N) {
		Vege(0, "hiba, �rv�nytelen param�ter GetP-ben");
	}
	return _F[x];
}  /*GetF*/

int Kerdes(int x) {

	if (Init) {
		Vege(0, "hiba, el?sz�r GetN-t kell h�vni");
	}
	if (x < 1 || x > _N) {
		Vege(0, "hiba, �rv�nytelen param�ter Kerdes-ben");
	}
	if (_K <= 0)
		Vege(0, "hiba, elfogyott a zseton");
	if (x < _bal) {
		return 0;
	}
	if (x >= _jobb) {
		return 1;
	}
	_K--;
	if (x < (_bal + _jobb) / 2) {
		_bal = x + 1;
		return 0;
	}
	else {
		_K += _F[x];
		_jobb = x;
		return 1;
	}
}  /*Kerdes*/

void Megoldas(int x) {
	if (Init) {
		Vege(0, "hiba, el?sz�r GetN-t kell h�vni");
	}
	if (_bal != _jobb) {
		Vege(0, "hiba, bl�ff�lt�l");
	}
	if (x != _bal) {
		Vege(0, "hiba, rossz v�lasz");
	}
	Vege(1, "helyes");
}  /*Megoldas*/
