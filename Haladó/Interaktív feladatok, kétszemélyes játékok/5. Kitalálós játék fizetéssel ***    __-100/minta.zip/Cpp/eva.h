#ifndef INTERAKTIV_KITALALOS_EVA_H
#define INTERAKTIV_KITALALOS_EVA_H

int GetN();
int GetK();
int GetP(int x);
int Kerdes(int x);
void Megoldas(int x);

#endif 
