#ifndef INTERAKTIV_KETJATEKOS_GEP_H
#define INTERAKTIV_KETJATEKOS_GEP_H

int Kezd();
int Mezo(int i, int j);
void Lep(char L);
char GepLep();

#endif
