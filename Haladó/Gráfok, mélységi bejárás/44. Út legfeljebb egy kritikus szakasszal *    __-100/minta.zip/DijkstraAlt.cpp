#include <iostream>
#include <queue>
#include <vector>
#define MaxN 100001
#define Inf 200000000
using namespace std;
struct Cella {
  long pont;
  long suly;
  Cella* csat;
};

Cella* G[MaxN];
int Apa[MaxN];
long Tav[MaxN];
bool Kesz[MaxN];
long n, s;

void Beolvas(){
}
int main(){
    Beolvas();
    priority_queue< pair<long, int> > Psor;
    Cella* uvel;
    long v; long Duv;
	for (int v = 1; v <= n; ++v){
	    Kesz[v]=false;
		if (v == s)
			Tav[v] = 0;
		else
			Tav[v] = Inf;
		Apa[v] = 0;
		Psor.push(make_pair(-Tav[v], v));
	}

	while (Psor.size() >0){
		pair<long, int> u= Psor.top(); Psor.pop();
		if (Kesz[u.second]) continue;
		Kesz[u.second] = true;
		uvel = G[u.second];
		while (uvel != NULL){
			v = uvel -> pont;
			if (!Kesz[v]){
                Duv=Tav[u.second]+uvel -> suly;
                if (Duv<Tav[v]){
                    Tav[v] = Duv;
                    Apa[v] = u.second;
                    Psor.push(make_pair(-Duv, v));
                }
			}
			uvel=uvel->csat;
		}
	}
//eredmény kiíratása
    return 0;
}
