﻿#include <iostream>
#include <stdio.h>
#include <stdlib.h>

#define MaxN 10000
#define MaxM 1000000

struct El{
  int kezd,veg;
  long suly;
};

int n,m;
El G[MaxM];
int Fa[MaxN];
int Apa[MaxN];

void Beolvas(){
  int x,y; long z;
  scanf("%d %d",&n,&m);
  for (int i=1; i<=m; i++){
    scanf("%d %d %d",&x,&y,&z);
    G[i].kezd=x; G[i].veg=y; G[i].suly=z;
  }
}
void UnioHolvan(int n){
	for (int x = 1; x <= n; ++x)
		Apa[x] = -1;
}

int Holvan(int x){
	int Nx = x;
	while (Apa[Nx] > 0)
		Nx = Apa[Nx];
	int y = x;
//úttömörités
	while (x != Nx){
		y = Apa[x];
		Apa[x] = Nx;
		x = y;
	}
	return Nx;
}

void Unio(int Nx, int Ny){
	if (Nx == Ny)
		return;
	if (Apa[Nx] > Apa[Ny]){//egyesítés a nagyobbhoz
        Apa[Ny] += Apa[Nx];
        Apa[Nx] = Ny;
	}else{
        Apa[Nx] += Apa[Ny];
        Apa[Ny] = Nx;
	}
}

int rend_rel(const void* a, const void* b) {
  long x =((El*) a)->suly;
  long y =((El*) b)->suly;
  if (x == y) return 0;
  else if (x > y) return 1;
  else return -1;
}
void ElBovit(El Fa[], int x, int y){

}

int main(){
    Beolvas();
    qsort((char *)G, m, sizeof(El),  rend_rel);
    UnioHolvan(n);
    int Fa[MaxN];
    int Opt=0, elind=0;
    int Np,Nq;
    for (int i=1;i<=m;i++){
        Np = Holvan(G[i].kezd);
        Nq = Holvan(G[i].veg);
        if (Np!=Nq){
            Opt+=G[i].suly;
            Fa[++elind]=i;
	    Unio(Np, Nq);
        }
    }
}
