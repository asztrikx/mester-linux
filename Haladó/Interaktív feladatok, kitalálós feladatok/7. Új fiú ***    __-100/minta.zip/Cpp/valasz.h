#ifdef __cplusplus
extern "C" {
#endif 

extern int GetN();
extern int Barat (int x, int y);
extern void Megoldas (int m);

#ifdef __cplusplus
}
#endif
