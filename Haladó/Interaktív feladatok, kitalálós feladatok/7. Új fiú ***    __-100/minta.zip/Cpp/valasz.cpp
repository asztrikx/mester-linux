#include <stdio.h>
#include <stdlib.h>
#include "valasz.h"

#define MaxN            1000001
#define true 1
#define false 0

int Init = true;
 int _N, _c;
 int _Kerd;
 int _MaxK;
 int _B[MaxN];
 int _K[MaxN];

void Vege(int jo ,char *S){
  if (jo > 0 && _Kerd <= _MaxK) {
    printf("%d\n", jo);
    printf("HELYES\n");
  }else {
    printf("%d\n", 0);
    puts(S);
  }
  printf("%d <=? %d\n", _Kerd, _MaxK);
  exit(0);
}  /*Vege*/

 void Kezd(){  /*BeolVas*/
  int n1, x, i;
  scanf("%d%d%d%*[^\n]", &_N, &n1, &_c);
  getchar();
  for (x = 1; x <= _N; x++) {
    _K[x] = 0;
    _B[x] = false;
  }
  for (i = 1; i <= n1; i++) {
    scanf("%d", &x);
    _B[x] = true;
  }
  _Kerd = 0;
  _MaxK = _N * 3 / 2;
}  /*Kezd*/

int GetN(){
  if (Init) {
    Kezd();
    Init = false;
  }
  return _N;
}  /*GetN*/

int Barat(int x, int y){  /*Kerdes*/
  int Result;
  if (Init) {
    Vege(0L, "HIBA; Előbb GetN kell!");
  }
  if (x < 1 || x > _N || y < 1 || y > _N) {
    Vege(0L, "HIBA; hibás sorszám!");
  }
  _Kerd++;
  if (_Kerd > _MaxK) {
    Vege(0L, "HIBA; a kérdésszám > 3N/2");
  }
  if (x == y) {
    Result = 1;
    _K[x]++;
    return Result;
  }
  _K[x]++;
  _K[y]++;
  if (x == _c || y == _c) {
    return 0;
  }
  if (_B[x] ^ _B[y]) {
    return 0;
  } else {
    return 1;
  }
}  /*Barat*/

void Megoldas(int m){
  int pont = 2;
  int i;
  if (Init) {
    Vege(0L, "HIBA; Előbb GetN kell!");
  }
  if (m < 1 || m > _N) {
    Vege(0L, "HIBA; hibás sorszám");
  }
  if (m != _c) {
    Vege(0L, "HIBA; nem helyes a válasz!");
  }
  for (i = 1; i <= _N; i++) {
    if (_K[i] > 5) {
      pont = 1;
      break;
    }
  }
  Vege(pont, "Helyes");
}  /*Megoldas*/
