#ifndef ZASZLO_H
#define ZASZLO_H

#include <iostream>

using namespace std;


int kezdet();
int kerdes(int a);
void eredmeny(int p, int f, int z);

#endif // ZASZLO_H
