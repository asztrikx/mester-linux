#include "zaszlo.h"

#include <iostream>

using namespace std;

static int _n;
static int _pp;
static int _ff;
static int _zz;
static bool _init;

int kezdet()
{
    _init=false;
    cin >>_n;
    cin >>_pp >>_ff >>_zz;
    return _n;
}

int kerdes(int aa)
{
    if (_init)
    {
        cout << "HIBA, elobb hivd a kezdet muveletet!" << endl;
    }
    if ((aa<1) or (aa>_n))
    {
        cout << "HIBA, ervenytelen kerdes!" << endl;
    }
    if (aa<=_pp)
    {
        return 1;
    }
    else if (aa<=_pp+_ff)
    {
        return 2;
    }
    else
    {
        return 3;
    }
}

void eredmeny(int p, int f, int z)
{
    if ((p==_pp) && (f==_ff) && (z==_zz))
    {
        cout << "TRUE" << endl;
    }
    else
    {
        cout << "FALSE" << endl;
    }
    exit(0);
}
