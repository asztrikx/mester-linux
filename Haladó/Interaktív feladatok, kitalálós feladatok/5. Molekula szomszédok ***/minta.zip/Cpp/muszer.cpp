//muszer könvtári modul
#include <iostream>
#include <stdlib.h>
#include <string>
#include "muszer.h"

#define _maxN 10001

using namespace std;

int _N;
int _kerd = 0;
int _Init = true;
int _M[_maxN];
int _Mi[_maxN];
int _S[_maxN];

int Atomszam() {
	int x;
	if (_Init) {
		cin >> _N;
		_Init = false;
		_kerd = 0;
		for (int i = 1; i <= _N; i++) {
			cin >> x;
			_M[i] = x;
			_Mi[x] = i;
			_S[i] = 0;
		}
	}
	return _N;
}
void Ki(double pont, string s) {
	cout.precision(1);
	cout << pont << " pont" << endl;
	cout << s << endl;
	exit(0);
}
//
int Kozte(int x, int y) {
	if (_Init) {
		Ki(0, "hiba, előbb hívd az Atomszam műveletet");
	}
	_kerd++;
	if (_kerd > 3 * _N) {
		Ki(0, "hiba, túl sok kérdés volt");
	}
	if (x<1 || x>_N || y<1 || y>_N) {
		Ki(0, "hiba, érvénytelen Kozte paraméter");
	}
	if (x == y) return x;
	int xi = _Mi[x], yi = _Mi[y];
	if (xi < yi) {
		return _M[xi + 1];
	}
	else {
		return _M[yi + 1];
	}
}

void Sorrend(int i, int x) {
	static int calls = 0;
	++calls;
	if (i<1 || i>_N || x<1 || x>_N) {
		Ki(0, "hiba, érvénytelen Sorrend paraméter");
	}

	_S[i] = x;
	if (calls == _N) {
		if (_M[1] == _S[1]) {
			for (int ii = 1; ii <= _N; ii++)
				if (_S[ii] != _M[ii]) {
					Ki(0, "hiba, rossz sorrend");
				}
		}
		else {
			for (int ii = 1; ii <= _N; ii++)
				if (_S[ii] != _M[_N - ii + 1]) {
					Ki(0, "hiba, rossz sorrend");
				}
		}
		if (_kerd <= 2 * _N)
			Ki(1, "helyes");
		else if (_kerd <= 3 * _N)
			Ki(0.5, "helyes");
		else
			Ki(0, "hiba, túl sokat kérdezett");
	}

}
