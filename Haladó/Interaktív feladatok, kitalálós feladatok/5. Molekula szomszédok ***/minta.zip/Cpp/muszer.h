extern int Atomszam();
extern int Kozte(int x, int y);
extern void Sorrend(int i, int x);
