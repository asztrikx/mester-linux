//muszer gyakorló könvtári modul
#include <iostream>
#include <stdlib.h>
#include "muszer.h"
#define _maxN 1001

using namespace std;

int _N,_K;
int _kerd=0;
int _Init=true;

int Atomszam(){
   int x,y;
   if (_Init) {
      cin>>_N;
      _Init = false;
      _kerd=0;
      _K=rand()%(_N-2)+2;
  }
  return _N;
}

void Ki(string s){
  cout<<s<<endl;
  exit(0);
}
//
int Kozte(int x, int y){
   if(_Init)
      Ki("Protokoll hiba, előbb hívd az Atomszam műveletet!");
   _kerd++;
   if(x==y || x<1 || x>_N || y<1 || y>_N)
         Ki("Protokoll hiba, hibás paraméterek!");
   if(x==_K){
      if(y<_K) return y+1;
      else return y-1;
   }else if(y==_K){
      if(x<_K) return x+1;
      else return x-1;
   }
   if(x!=_N && y!=_N){
      if(x<y)
         return x+1;
      else
         return x-1;
   }else{
      if(x==_N){int xx=x; x=y; y=xx;}
      if(_K<x){
         return x-1;
      }else if(x<_K){
         return x+1;
      }else{
         return x;
      }
   }
}
void Kozpont(int x){
   if(x==_K)
      cout<<"Központ="<<x<<", kérdésszám="<<_kerd<<endl;
   else
      Ki("Ez nem a központ");
   exit(0);
}
