extern int hany(void);
extern int kerdes(int x, int y);
extern void megoldas(int m);
