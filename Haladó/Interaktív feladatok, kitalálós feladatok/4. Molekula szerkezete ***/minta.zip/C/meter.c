#include "meter.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MaxN            100001L
#define true 1
#define false 0

typedef long Map[MaxN];

static int Init = true, Test = false;
static long N;
static Map P, PP, QQ;
static long MaxA, HH;

static void Abort(double pont, char *msg)
{
	printf("%.1f pont\n%s\n", pont*5, msg);
	exit(0);
}

static void Initialise()
{
	long x, y;
	scanf("%ld", &N);

	for (x = 1; x <= N; x++) {
		PP[x] = -1; QQ[x] = 0;
	}
	for (x = 1; x <= N; x++) {
		scanf("%ld", &y);
		P[x] = y;
		PP[y] = x;
	}

	MaxA = 0;
	HH = 0;
	Init = false;
}

long meret()
{
	if (Init)
		Initialise();
	return N;
}

void holvan(long x, long i)
{
	if (Init)
		Abort(0, "hiba, el?sz�r meret-et kell h�vni");
	HH++;
	if (x < 1 || x > N || i < 1 || i > N) {
		Abort(0,"hiba, �rv�nytelen param�ter holvan-ban");
	}
	QQ[i] = x;
	if (HH != N)
		return;

	int jo1 = true, jo2 = true;
	for (int j = 1; j <= N; ++j) {
		if (QQ[j] != P[j]) { jo1 = false; }
		if (QQ[j] != P[N - j + 1]) { jo2 = false; }
	}
	if (!jo1 && !jo2) {
		Abort(0, "hiba, rossz megold�s");
	}
	if (MaxA <= (3 * N) / 2) {
		Abort(1, "helyes");
	}
	if (MaxA <= 2 * N) {
		Abort(0.8, "helyes");
	}
	if (MaxA <= N*log2(N)) {
		Abort(0.6, "helyes");
	}
	Abort(0.2, "helyes");
}

long kozepen(long x, long y)
{
	long px, py, pk;

	if (Init) {
		Abort(0, "hiba, el?sz�r meret-et kell h�vni");
	}
	if (x < 1 || x > N || y < 1 || y > N) {
		Abort(0,"hiba, �rv�nytelen param�ter kozepen-ben");
	}
	MaxA++;
	px = PP[x];
	py = PP[y];
	if (px <= py)
		pk = (px + py) / 2;
	else
		pk = (px + py + 1) / 2;
	return (P[pk]);
}

