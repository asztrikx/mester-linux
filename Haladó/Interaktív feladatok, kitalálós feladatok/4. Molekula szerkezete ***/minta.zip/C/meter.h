#ifdef __cplusplus
extern "C" {
#endif

extern long meret();
extern long kozepen (long x, long y);
extern void holvan (long x, long i);
#ifdef __cplusplus
}
#endif
