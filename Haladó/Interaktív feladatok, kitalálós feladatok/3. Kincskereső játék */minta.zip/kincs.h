extern int Helyekszama();
extern int Szomszed(int x);
extern int Ittvan(int x);
extern void Kincshely(int x);
