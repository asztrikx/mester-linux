#ifndef INTERAKTIV_SZAMZAR_ZAR_H
#define INTERAKTIV_SZAMZAR_ZAR_H

#include <string>

void resetA();
std::string jelszo();
void be(char x);
bool nyito();
void nyit(std::string k);

#endif