extern int TanulokSzama();
extern int Barat (int x, int y);
extern void Megoldas (int &a, int &b, int &c);
