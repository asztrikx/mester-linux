#include <iostream>
#include <stdlib.h>
#include <string>
#include "valasz.h"
#define maxN 10001
using namespace std;

int _n=0;
int _Kerd;
int _Hany[maxN];

void Kezd(){
  cin>>_n;
  for (int x = 1; x <=_n; x++)
      _Hany[x]=0;
  _Kerd = 0;
}  /*Kezd*/

int TanulokSzama(){
   Kezd();
   return _n;
}

int Barat(int x, int y){
  if (_n==0){
      cout<<"HIBA, Előbb TanulokSzama kell!"<<endl;
      exit(0);
  }
  if (x < 1 || x > _n || y < 1 || y > _n){
   cout<<"HIBA, hibás sorszám!"<<endl;
      exit(0);
  }
  _Kerd++;
  if (_Kerd > 2*_n-2){
      cout<<"HIBA, túl sok kérdés volt"<<endl;
      exit(0);
  }
  _Hany[x]++; _Hany[y]++;
   if(_Hany[x]>4 || _Hany[y]>4){
      cout<<"HIBA, 4-nél több kérdés egy tanulóra"<<endl;
      exit(0);
   }
   if(x==y || x>2 && y>2)
      return 1;
   else
      return 0;
}  /*Barat*/

void Megoldas(int &a, int &b, int &c){
   if (a < 1 || a > _n || b<1 || b>_n || c<1 || c>_n){
    cout<<"HIBA, hibás sorszám"<<endl;
    exit(0);
   }
   if (a==b || a==c || b==c)
    cout<<"HIBA, nem helyes a válasz!"<<endl;
  if (a+b+c!=6)
    cout<<"HIBA, nem helyes a válasz!"<<endl;
   else
      cout<<"Helyes"<<endl;
   exit(0);
}
