#include <iostream>
#include <queue>
#define maxN 1234

using namespace std;
int G[maxN][maxN];
int Elso[maxN][maxN];
long long T[maxN][maxN];

int n;

void Floyd_Warshall( ){
//Global:n, G, T, Elso
    for (int i=1;i<=n;i++)
        for (int j=1;j<=n;j++){
            T[i][j]=G[i][j];
            Elso[i][j]=i;
        }
    for (int k=1;k<=n;k++)
        for (int i=1;i<=n;i++)
            for (int j=1;j<=n;j++)
                if (T[i][k]+T[k][j]<T[i][j]){
                    T[i][j]=T[i][k]+T[k][j];
                    Elso[i][j]=Elso[i][k];
                }
}
void UtKiIro(int i, int j){
//i~j legrövidebb út kiíratása
//Global: Elso
    do{
        cout<<i<<" ";
        i=Elso[i][j];
    }while(i!=j);
    cout<<j<<endl;
}
int main(){

}
