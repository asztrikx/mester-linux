#include <iostream>
#define MaxN 100000
#define Inf 200000000
using namespace std;

struct Cella {
  long pont;
  long suly;
  Cella* csat;
};

Cella* G[MaxN];
long Apa[MaxN];
long Tav[MaxN];
bool Kesz[MaxN];
long eszam;
long meret;
long Fa[MaxN];
long Hol[MaxN];
long n, s;
//ModPrisor m�veletek
void Uresit();
long Elemszam();
void SorBa(long az);
long SorBol();
long Elso();
void Torol();
void Modosit(long az, long x);
void sullyeszt(long k);
void emel(long k);

void Kezd(long r);
void Kozelit(long u, long v, long uvs);

void Dijkstra(long s) {
//Global: s, Kesz, Tav, Apa
    Cella* uvel;
    long v; long Duv;
	Kezd(s);
	while (Elemszam() > 0){
		long u = SorBol();
		Kesz[u] = true;
		uvel = G[u];
		while (uvel != NULL){
			v = uvel -> pont;
			if (!Kesz[v]){
                Duv=Tav[u] +uvel -> suly;
                if (Duv<Tav[v]){    //k�zel�t�s
//                    Tav[v] = Duv;
                    Apa[v] = u;
                    Modosit(v, Duv);//m�dos�t�s
                }
			}
			uvel=uvel->csat;
		}
	}
}

void Kezd(long r){
    Uresit;
	for (long v = 1; v <= n; ++v){
		if (v == r)
			Tav[v] = 0;
		else
			Tav[v] = Inf;
		Apa[v] = 0;
		SorBa(v);
	}
}

void Kozelit(long u, long v, long uvs){
	long Duv = Tav[u] + uvs;
	if (Duv < Tav[v]){
		Tav[v] = Duv;
		Apa[v] = u;
		Modosit(v, Duv);
	}
}

void Uresit(){
	eszam = 0;
}

long Elemszam(){
	return eszam;
}

void SorBa(long az) {
	Fa[++eszam] = az;
	Hol[az] = eszam;
	emel(eszam);
}

long SorBol(){
	if (eszam == 0) return 0;
	long az = Fa[1];
	Fa[1] = Fa[eszam--];
	if (eszam > 0)
		sullyeszt(1);
	return az;
}

long Elso() {
	if (eszam == 0) return 0;
	return Fa[1];
}

void Torol(){
	Fa[1] = Fa[eszam--];
	if (eszam > 0)
		sullyeszt(1);
}

void Modosit(long az, long x){
	long k = Hol[az];
	bool ken = x < Tav[az];
	Tav[az] = x;
	if (ken)
		emel(k);
	else
		sullyeszt(k);
}

void sullyeszt(long k){
	long apa = k;
	long fiu;
	long az = Fa[k];
	long e = Tav[az];
	while ((fiu = apa << 1) <= eszam ){
	    if (fiu < eszam && Tav[Fa[fiu + 1]] < Tav[Fa[fiu]])
            ++fiu;
        if (e <= Tav[Fa[fiu]])
			break;
        Fa[apa] = Fa[fiu];
        Hol[Fa[fiu]] = apa;
        apa = fiu;
    }
    Fa[apa] = az;
    Hol[az] = apa;
}
void Beolvas(){
    long m, u,v, dij;
    Cella* uvel;
    cin>>n>>m>>s;
    for (long i=1;i<=n;i++) G[i]=NULL;
    for (long i=1;i<=m; i++){
        cin>>u>>v>>dij;
        uvel=new Cella;
        uvel->pont=v;
        uvel->suly=dij;
        uvel->csat=G[u];
        G[u]=uvel;

        uvel=new Cella;
        uvel->pont=u;
        uvel->suly=dij;
        uvel->csat=G[v];
        G[v]=uvel;
    }
}
void emel(long k){
    long az = Fa[k];
	long e = Tav[az];
	long fiu = k;
	long apa;
	while (fiu > 1)	{
		apa = fiu >> 1;
		if (e < Tav[Fa[apa]]){
			Fa[fiu] = Fa[apa];
			Hol[Fa[apa]] = fiu;
			fiu = apa;
		}
		else
			break;
	}
	Fa[fiu] = az;
	Hol[az] = fiu;
}
int main(){
    Beolvas();
    Kezd(s);
    Dijkstra(s);
    for (long i=1; i<=n;i++)
        if (Tav[i]==Inf)
            cout<<"-1 ";
        else
            cout<<Tav[i]<<" ";
    cout<<endl;
    return 0;
}
