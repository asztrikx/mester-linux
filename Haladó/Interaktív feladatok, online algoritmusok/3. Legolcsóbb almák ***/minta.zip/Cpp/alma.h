#ifndef INTERAKTIV_LEGOLCSOBB_ALMA_H
#define INTERAKTIV_LEGOLCSOBB_ALMA_H

const int maxn = 10000;

int getN();
int getK();
int ar();
void olcsobbak(int X[maxn]);

#endif
