#include "alma.h"
#include <cstdio>
#include <iostream>
#include <string>

using namespace std;

bool init = true, olcso;
int n, k, i = 0;

void vege(int, string msg) {
	cout << msg << endl;
	exit(0);
}

int getN() {
	if (!init) {
		vege(0, "hiba, getN-t csak egyszer szabad h�vni");
	}
	cin >> n >> k;
	init = false;
	return n;
}

int getK() {
	if (init) {
		vege(0, "hiba, el?sz�r getN-t kell h�vni");
	}
	return k;
}

int ar() {
	if (init) {
		vege(0, "hiba, el?sz�r getN-t kell h�vni");
	}
	++i;
	if (i > k && !olcso) {
		vege(0, "hiba, kimaradt egy olcsobbak h�v�s");
	}
	olcso = false;
	int x;
	cin >> x;
	return x;
}

void olcsobbak(int X[maxn]) {
	olcso = true;
	for (int j = 0; j < k; ++j) {
		if (j && X[j] <= X[j - 1]) {
			vege(0, "hiba, az X t�mb elemei nem n�vekv?en rendezettek");
		}
	}
	if (i == n) {
		vege(1, "helyes");
	}

}