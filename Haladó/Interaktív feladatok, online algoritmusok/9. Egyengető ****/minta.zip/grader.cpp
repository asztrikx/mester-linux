//minta grader modul
#include <bits/stdc++.h>
#include "grader.h"
#define maxN 200001
using namespace std;
int _A[maxN];
int _i=0,_n,_K;
bool _initN=false;
bool _initK=false;
bool _answered=false;

int getN(){
   ios_base::sync_with_stdio(false); cin.tie(NULL);
   if(_initN) return _n;
   cin>>_n>>_K;
   for(int i=0;i<_n;i++){
      cin>>_A[i];
   }
   _initN=true;
   return _n;
}
int getK(){
   if(!_initN){
      cout<<"Protocoll hiba, elobb getN-t kell hivni!"<<endl;
      exit(0);
   }
    _initK=true;
   return _K;
}
int Data(){
   if(!_initK){
      cout<<"Protocoll hiba, elobb getN-t es getK-t kell hivni!"<<endl;
      exit(0);
   }
   if(_i>1 &&!_answered){
      cout<<"Protocoll hiba"<<endl;
      exit(0);
   }
   return _A[_i];
}
void Solution(long long x){
   if(!_initK){
      cout<<"Protocoll hiba, elobb getN-t es getK-t kell hivni!"<<endl;
      exit(0);
   }
   _answered=true;
   _i++;
   if(_i==_n){
      cout<<"Helyes";
      exit(0);
   }
}
