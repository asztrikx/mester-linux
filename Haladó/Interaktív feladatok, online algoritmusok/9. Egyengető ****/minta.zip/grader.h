extern int Data();
extern void Solution(long long x);
extern int getN();
extern int getK();
