//ismer könvtári modul
#include <iostream>
#include <stdlib.h>
#include <string>
#include "ismer.h"
#define _maxN 10001

using namespace std;

int _N;
int _kerd = 0;
bool _Init = true;
bool mvolt = false;

void vege(int pont, string s) {
	cout << s << endl;
	exit(0);
}

int kezdet() {
	cin >> _N;
	mvolt = false;
	_Init = false;
	return _N;
}
void muvelet(char &k, int &a, int &b) {
	if (_Init) {
		vege(0, "HIBA, először kezdet-et kell hívni");
	}
	if (mvolt)
		vege(0, "HIBA, protokoll hiba!");
	cin >> k >> a >> b;
	if (k == 'v') {
		vege(1, "HELYES!");
	}
	mvolt = true;
}
void csoport(int db) {
	if (_Init) {
		vege(0, "HIBA, először kezdet-et kell hívni");
	}
	if (!mvolt) {
		vege(0, "Protokoll Hiba, nem volt muvelet hívás!");
	}
	mvolt = false;
}
//
