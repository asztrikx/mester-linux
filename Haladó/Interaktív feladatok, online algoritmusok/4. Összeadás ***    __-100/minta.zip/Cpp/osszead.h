#ifndef INTERAKTIV_OSSZEAD_H
#define INTERAKTIV_OSSZEAD_H

int getaN();
int getbN();
int geta();
int getb();
void kiir(int c);

#endif