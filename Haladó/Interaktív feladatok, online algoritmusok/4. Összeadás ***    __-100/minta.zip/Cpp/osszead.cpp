#include "osszead.h"
#include <cstdio>
#include <iostream>
#include <string>

using namespace std;

string a, b;
unsigned ai, bi;
bool init = true;

void vege(int pont, string msg) {
	cout << msg << endl;
	exit(0);
}

void kezd() {
	cin >> a >> b;
	ai = bi = 0;
	init = false;
}

int getaN() {
	if (init) { kezd(); }
	return a.length();
}

int getbN() {
	if (init) { kezd(); }
	return b.length();
}

int geta() {
	if (init) { kezd(); }
	if (ai >= a.length()) {
		vege(0, "hiba, geta h�v�s az utols� jegy ut�n");
	}
	return a[ai++] - '0';
}

int getb() {
	if (init) { kezd(); }
	if (bi >= b.length()) {
		vege(0, "hiba, getb h�v�s az utols� jegy ut�n");
	}
	return b[bi++] - '0';
}

void kiir(int c) {
	if (init) { kezd(); }
	if (c == -1) {
		cout << endl;
		vege(1, "helyes");
	}
	if (c < 0 || c > 9) {
		vege(0, "hiba, �rv�nytelen kiir param�ter");
	}
	cout << c;
}