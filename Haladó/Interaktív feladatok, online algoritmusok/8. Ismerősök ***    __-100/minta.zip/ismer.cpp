//ismer könvtári modul
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
//#include "ismer.h"
#define _maxN 10001

using namespace std;

int _N;
int _kerd=0;
bool _Init=true;
bool mvolt=false;
int mdb;

void Ki(string s){
  cout<<s<<endl;
  exit(0);
}
int kezdet(){
//   cin>>_N;
   string s;

   scanf("%d",&_N);
   getline(cin,s);
   mvolt=false;
   return _N;
}
void muvelet(char &k, int &a, int &b){
   string s;
   if(mvolt)
      Ki("1;0;Hiba, protokoll hiba!");
      scanf("%c %d %d",&k,&a,&b);
      getline(cin,s);
   if(k=='v'){
      Ki("1;1;Helyes");
      exit(0);
   }
   scanf("%d",&mdb);
   getline(cin,s);
   mvolt=true;
}
void csoport(int db){
   if(!mvolt){
      Ki("1;0;Hiba, protokoll hiba!");
   }
   if(db!=mdb){
      Ki("1;0;Hiba, hibás válasz!");
   }
   mvolt=false;
}
//
