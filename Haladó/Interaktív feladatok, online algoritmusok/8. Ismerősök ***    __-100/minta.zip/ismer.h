int kezdet();
void muvelet(char &k, int &a, int &b);
void csoport(int db);
