extern int Telepulesszam();
extern int Utszam();
extern int Vam(int i);
extern void VanUt(int &x, int &y);
extern void Igeny(int &t, int &x, int &y);
extern void Utvam(int s);
