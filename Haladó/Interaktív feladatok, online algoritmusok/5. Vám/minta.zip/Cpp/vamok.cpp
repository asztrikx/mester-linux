﻿#include <iostream>
#include <stdlib.h>
#include "vamok.h"
#define maxN 501
#define maxM 250002

using namespace std;
typedef struct{
   int x,y;
}_Eltip;

bool _Init=false;
int _n,_m,_eldb=0;
bool _kell=false;
int _V[maxN];
_Eltip _El[maxM];

void Vege(int pont, string s){
   cout<<pont<<endl;
   cout<<s<<endl;
   exit(0);
}
int Telepulesszam(){
   if(_Init) Vege(0,"Protokoll hiba");
   cin>>_n>>_m;
   for(int i=1;i<=_n;i++)
      cin>>_V[i];
   string ss;
   getline(cin,ss);
   for(int i=1;i<=_m;i++)
      cin>>_El[i].x>>_El[i].y;
   _Init=true;
   return _n;
}
int Utszam(){
   if(!_Init) Vege(0,"Protokoll hiba");
   return _m;
}
int Vam(int i){
   if(!_Init) Vege(0,"Protokoll hiba");
   if(i<1 || i>_n){
      Vege(0,"Hibás sorszám");
   }
   return _V[i];
}

void VanUt(int &x, int &y){
   if(!_Init) Vege(0,"Protokoll hiba");
   _eldb++;
   if(_eldb<=_m){
      x=_El[_eldb].x; y=_El[_eldb].y;
   }else{
      Vege(0,"Túl sok útszakasz");
   }
}
void Igeny(int &t, int &x, int &y){
   if(!_Init) Vege(0,"Protokoll hiba");
   if (_kell){
      Vege(0,"Protokoll hiba");
   }
   cin>>t>>x>>y;
   string ss;
   getline(cin,ss);
   if(t==0){
      Vege(1,"Helyes");
   }
   if(t==1) _kell=true;
}
void Utvam(int s){
   if(!_Init) Vege(0,"Protokoll hiba");
//nem ellenőrzi a helyességet
   _kell=false;
}

