#include <iostream>
#include "lekiki.h"

using namespace std;

void Adat(int x){

}
int Mex(int a){

}
