extern void Adat(int x);
extern int Mex(int a);
