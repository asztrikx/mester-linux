#include <stdio.h>
#include <stdlib.h>
#include "halo.h"

#define MAXN 1000

static int n;
static int gr[MAXN + 1][MAXN + 1];
static int ffa[MAXN + 1][MAXN + 1];

int kezdet() {
	scanf("%d%*[ \n\t]", &n);
	int i, j;
	for (i = 1; i <= n; i++) {
		for (j = 1; j <= n; j++) {
			gr[i][j] = 0;
			ffa[i][j] = 0;
		}
	}
	return n;
}

void kiir(int pont, char* msg) {
	printf("%s\n",  msg);
	exit(0);
}

void ajanlat(int &a, int &b, int &c) {
	scanf("%d%*[ \n\t]%d%*[ \n\t]%d%*[ \n\t]", &a, &b, &c);
	if (a == 0) {
		kiir(1, "helyes");
	}
	gr[a][b] = c;
	gr[b][a] = c;
}

void hozzaad(int a, int b) {
	if (a<1 || a > n || b < 1 || b > n) {
		kiir(0, "�rv�nytelen hozzaad param�ter");
	}
	if (gr[a][b] > 0 && ffa[a][b] == 0) {
		ffa[a][b] = gr[a][b];
		ffa[b][a] = gr[a][b];
	}
	else {
		kiir(0, "hiba, �rv�nytelen hozzaad m?velet");
	}
}

void elvesz(int a, int b) {
	if (a<1 || a > n || b < 1 || b > n) {
		kiir(0, "�rv�nytelen elvesz param�ter");
	}
	if (gr[a][b] > 0 && ffa[a][b] > 0) {
		ffa[a][b] = 0;
		ffa[b][a] = 0;
	}
	else {
		kiir(0, "hiba, �rv�nytelen elvesz m?velet");
	}
}
