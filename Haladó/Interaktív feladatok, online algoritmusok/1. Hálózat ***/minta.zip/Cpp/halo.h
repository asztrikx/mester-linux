#ifndef HALO_H_INCLUDED
#define HALO_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

int kezdet();
void ajanlat(int &a, int &b, int &c);
void hozzaad(int a, int b);
void elvesz(int a, int b);

#ifdef __cplusplus
}
#endif

#endif // HALO_H_INCLUDED
