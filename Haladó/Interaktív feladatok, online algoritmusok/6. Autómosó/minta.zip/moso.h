extern int MosoSzam();
extern int Sorhossz();
extern void Erkezik(int &e, int &t);
extern void Tavozik(int x);
