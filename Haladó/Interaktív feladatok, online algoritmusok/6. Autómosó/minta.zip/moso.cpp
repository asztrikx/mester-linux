#include <iostream>
#include <stdlib.h>
#include "moso.h"

using namespace std;

bool _Init=false;
int _M,_H=0;
bool _kell=false;
long long _ered=0;

void Vege(string s){
   cout<<s<<endl;
   exit(0);
}
int MosoSzam(){
   if(_Init) Vege("Protokoll hiba");
   cin>>_M>>_H;
   _Init=true;
   return _M;
}
int Sorhossz(){
   if(!_Init) Vege("Protokoll hiba");
   return _H;
}

void Erkezik(int &e, int &t){
   if(!_Init) Vege("Protokoll hiba");
   if (_kell){
      Vege("Protokoll hiba");
   }
   cin>>e>>t;
   if(e==0){
      if(_kell)
         Vege("Protokoll hiba");
      Vege("Helyes");
   }
   _kell=true;
}
void Tavozik(int s){
   if(!_Init) Vege("Protokoll hiba");
   _kell=false;
}
