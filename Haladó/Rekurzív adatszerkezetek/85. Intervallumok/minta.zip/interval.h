extern void Bovit(int a, int b);
extern void Torol(int a, int b);
extern void MetszKeres(int xa, int xb, int &a, int &b);
