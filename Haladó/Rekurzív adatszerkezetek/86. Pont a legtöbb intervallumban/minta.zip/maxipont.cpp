#include <iostream>
#include <time.h>
#include <stdio.h>
#include <cstdlib>
#include <set>
#include "maxipont.h"
using namespace std;

void Vege(int pont, string S){
   cout<<pont<<endl;
   cout<<S<<endl;
  exit(0);
}  /*Vege*/

class _Inter{
   public:
   int a,b;
   _Inter(){};
   _Inter(int x, int y){
      a=x; b=y;
   }
    bool operator<(const _Inter& jobb) const{
      return a<jobb.a || a==jobb.a && b>jobb.b;
   }
};
multiset<_Inter>_R;

bool _MPont(int x){
   int valasz=0;
   int ossz=0;
   int hany=0;
   for(auto ab:_R){
      ossz+=(ab.b);
      if(ossz>valasz) valasz=ossz;
      if(ab.a>x) continue;
      if(ab.b>0)
         hany++;
      else if(ab.a<x) hany--;
   }
   return hany==valasz;
}
int _Hany(){
   int valasz=0;
   int ossz=0;
   for(auto ab:_R){
      ossz+=(ab.b);
      if(ossz>valasz) valasz=ossz;
   }
   return valasz;
}
int main(){
   int n,M,x,y,xn,vn;
   bool jo;
   cin>>n;

   for(int i=0;i<n;i++){
      M=rand()%4;
      switch(M) {
         case 0:
            x=rand();
            y=rand();
            if(x<=y){
               _R.insert({x,1});
               _R.insert({y,-1});
               Bovit(x,y);
            }else{
               _R.insert({x,-1});
               _R.insert({y,1});
               Bovit(y,x);
            }
            break;
         case 1:
            if(_R.size()==0) break;
            x=MaxiPont();
            jo=_MPont(x);
            if(!jo) Vege(0,"Hibás_MaxPont");
            break;
         case 2:
            if(_R.size()==0) break;
            xn=_Hany();
            vn=MaxiHany();
             if(xn!=vn) {
                  Vege(0,"Hibás_MaxHany");
             }
         break;
         case 3: //torol
            break;
            if(_R.size()==0) break;
            break;
      }
   }
   Vege(1,"Helyes");
}
