extern void Bovit(int a, int b);
extern void Torol(int a, int b);
extern int MaxiHany();
extern int MaxiPont();
