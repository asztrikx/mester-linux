extern void Adat(int x);
extern int Elemszam();
extern int Kadik(int k);
extern int Hanyadik(int x);
