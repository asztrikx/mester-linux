#include <bits/stdc++.h>
using namespace std;
extern void Kezd(string s);
extern void Beszur(int i, char x);
extern void Mutal(int i, char x);
extern void Kivag(int i, int j);
extern int Szamlal(int i, int j, char x);
extern string Eredmeny();
