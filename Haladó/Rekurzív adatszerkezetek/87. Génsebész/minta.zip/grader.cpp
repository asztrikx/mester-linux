#include <bits/stdc++.h>
#include "grader.h"
using namespace std;
int main(){
   string _DNSs="",sor="";
   int m=1,i=0,j,sz,jo;
   char x;
   long long _digi=1234152436374;
   string veg;
   cin>>_DNSs;
   Kezd(_DNSs);
   for(;;){
      cin>>m; m=(m+5)%6;
      switch(m) {
         case 0: cin>>i; cin>>x; getline(cin,sor);
            Beszur(i, x);
            break;
         case 1: cin>>i; cin>>x; getline(cin,sor);
            Mutal(i, x);
            break;
         case 2: cin>>i; cin>>j; getline(cin,sor);
            Kivag(i, j);
            break;
         case 3: cin>>i; cin>>j; cin>>x; cin>>jo; getline(cin,sor);
               sz=Szamlal(i, j, x); sz++;
               if(sz!=jo){
                  cout<<_digi<<endl;
                  cout<<0<<endl;
                  return 0;
               }
            break;
         case 4: _DNSs=Eredmeny()+'#';
               cin>>sor;
               getline(cin,veg);
                  switch(_DNSs[0]){
                     case 'A': _DNSs[0]='C'; break;
                     case 'C': _DNSs[0]='G'; break;
                     case 'G': _DNSs[0]='T'; break;
                     case 'T': _DNSs[0]='A'; break;
                  }
               if(sor!=_DNSs){
                  cout<<_digi<<endl;
                  cout<<0<<endl;
                  return 0;
               }
            break;
         case 5:
               _DNSs=Eredmeny()+'#';
               cin>>sor;
               getline(cin,veg);
               switch(_DNSs[0]){
                  case 'A': _DNSs[0]='C'; break;
                  case 'C': _DNSs[0]='G'; break;
                  case 'G': _DNSs[0]='T'; break;
                  case 'T': _DNSs[0]='A'; break;
               }
              cout<<_digi<<endl;
               if(sor!=_DNSs)
                  cout<<0<<endl;
               else
                  cout<<1<<endl;
               return 0;
            break;
      }
   }
   return 0;
}
