extern void Beszur(int i, int x);
extern int Kadik(int k);
extern void Torol(int x);
extern void Modosit(int k, int x);
extern int Elemszam();
